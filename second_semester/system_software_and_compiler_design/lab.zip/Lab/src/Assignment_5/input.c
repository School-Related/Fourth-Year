int main() {
    int x = 10;
    float y = 20.5;
    x = x + y;
    return 0;
}