package tables;

public enum SymbolType {
    SYMBOL, CONSTANT
}
