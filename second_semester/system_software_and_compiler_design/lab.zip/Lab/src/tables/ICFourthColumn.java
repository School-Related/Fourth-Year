package tables;

public interface ICFourthColumn {
    Integer getValue();
    SymbolType getType();
}
